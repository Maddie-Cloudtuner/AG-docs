"""Handlers package"""
from app.handlers.health import HealthHandler

__all__ = ["HealthHandler"]
