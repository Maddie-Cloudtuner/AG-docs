"""
Virtual Tagging Application - Python/FastAPI Implementation
"""

__version__ = "1.0.0"
