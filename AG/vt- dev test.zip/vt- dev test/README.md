# 🏷️ Virtual Tagging System

**Automated Cloud Resource Tagging Platform**

---

## 🚀 Quick Start (One Command)

### Windows
```powershell
# Right-click setup.ps1 → "Run with PowerShell"
# OR
.\setup.ps1
```

### Linux/Mac
```bash
chmod +x setup.sh
./setup.sh
```

**That's it!** The script will:
- ✅ Check prerequisites (Docker, Node.js)
- ✅ Set up backend (Docker containers)
- ✅ Run database migrations
- ✅ Set up frontend (npm install)
- ✅ Offer to start the dev server

---

## 📋 Prerequisites

Before running setup:
1. **Docker Desktop** - [Download](https://www.docker.com/products/docker-desktop)
2. **Node.js 18+** - [Download](https://nodejs.org/)

---

## 🎯 Access Points

After setup completes:

| Service | URL | Status |
|---------|-----|--------|
| Frontend | http://localhost:5173 | Run `npm run dev` in `client/` |
| Backend API | http://localhost:8000 | ✅ Auto-started |
| Database | localhost:5432 | ✅ Auto-started |

---

## 📁 Project Structure

```
virtual-tagging-prototype/
├── python/          # Backend (Python/Tornado)
├── client/          # Frontend (React)
└── setup.ps1        # Automated setup script
```

---

## 🛑 Stop Services

```powershell
cd python
docker-compose down
```

---

## 📚 Documentation

- **Architecture Guide**: `architecture_guide.md`
- **Developer Docs**: `DEVELOPER_DOCUMENTATION.md`
- **Automation Guide**: `AUTOMATION_GUIDE.md`
- **Deployment**: `DEPLOYMENT_PACKAGE.md`

---

## ❓ Troubleshooting

**Backend not starting?**
```powershell
cd python
docker-compose logs backend
```

**Frontend errors?**
```powershell
cd client
rm -rf node_modules
npm install
npm run dev
```

**Database issues?**
```powershell
cd python
docker-compose down -v  # Removes volumes
docker-compose up -d
```

---

## 🎉 Features

- ✅ Automated resource discovery
- ✅ ML-based tag inference
- ✅ Tag approval workflow
- ✅ Bulk CSV import/export
- ✅ Rule-based tagging
- ✅ Complete audit trail
- ✅ Scheduled auto-tagging

---

**Built with Python, React, and PostgreSQL**
