<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('bg-dark-900 text-slate-50 antialiased'); ?>>

<nav class="fixed top-0 w-full z-50 bg-dark-900/80 backdrop-blur-md border-b border-white/10">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex items-center justify-between h-16">
            <div class="flex items-center">
                <a href="<?php echo home_url(); ?>" class="flex-shrink-0">
                    <span class="font-heading text-2xl font-bold text-white">
                        Cloud<span class="text-primary">Tuner</span>
                    </span>
                </a>
                <div class="hidden md:block ml-10">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'flex items-baseline space-x-4',
                        'add_li_class' => 'hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors text-slate-300'
                    ));
                    ?>
                </div>
            </div>
            <div class="hidden md:block">
                <div class="ml-4 flex items-center md:ml-6 space-x-4">
                    <a href="https://dev.dashboard.cloudtuner.ai/public" class="text-sm font-medium hover:text-white text-slate-300">Log In</a>
                    <a href="/tools/audit" class="bg-primary hover:bg-primary-dark text-dark-900 px-4 py-2 rounded-full text-sm font-bold transition-all">Launch Audit Tool</a>
                </div>
            </div>
        </div>
    </div>
</nav>

<main class="min-h-screen pt-20">
