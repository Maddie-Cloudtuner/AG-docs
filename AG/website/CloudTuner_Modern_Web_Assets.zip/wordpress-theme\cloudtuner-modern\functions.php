<?php

function cloudtuner_setup() {
    // Add title tag support
    add_theme_support('title-tag');
    
    // Add post thumbnail support
    add_theme_support('post-thumbnails');
    
    // Register Menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'cloudtuner'),
        'footer' => __('Footer Menu', 'cloudtuner'),
    ));
}
add_action('after_setup_theme', 'cloudtuner_setup');

function cloudtuner_scripts() {
    // Enqueue Main Styles
    wp_enqueue_style('cloudtuner-style', get_stylesheet_uri());
    
    // Enqueue Tailwind CSS (CDN for demonstration/dev - recommend build step for prod)
    wp_enqueue_script('tailwindcss', 'https://cdn.tailwindcss.com', array(), '3.4.0', false);
    
    // Configure Tailwind Theme
    wp_add_inline_script('tailwindcss', "
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: { DEFAULT: '#00D4FF', dark: '#00A3C4' },
                        secondary: { DEFAULT: '#6C5CE7', dark: '#5040B2' },
                        dark: { 900: '#0F172A', 800: '#1E293B' }
                    },
                    fontFamily: {
                        sans: ['Inter', 'sans-serif'],
                        heading: ['Outfit', 'sans-serif']
                    }
                }
            }
        }
    ");
    
    // Enqueue Google Fonts
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Outfit:wght@500;700&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'cloudtuner_scripts');
