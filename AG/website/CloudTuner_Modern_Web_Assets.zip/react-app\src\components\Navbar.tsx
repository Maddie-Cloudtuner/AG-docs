"use client";
import Link from "next/link";
import { useState } from "react";
import { Menu, X, ChevronDown } from "lucide-react";

export default function Navbar() {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <nav className="fixed top-0 w-full z-50 bg-dark-900/80 backdrop-blur-md border-b border-white/10">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex items-center">
                        <Link href="/" className="flex-shrink-0">
                            <span className="font-heading text-2xl font-bold text-white">
                                Cloud<span className="text-primary">Tuner</span>
                            </span>
                        </Link>
                        <div className="hidden md:block">
                            <div className="ml-10 flex items-baseline space-x-4">
                                <Link href="/solutions/kubernetes-cost" className="hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors">
                                    Cost Optimization
                                </Link>
                                <Link href="/solutions/smart-contract-audit" className="hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors">
                                    Security Audit
                                </Link>
                                <Link href="/pricing" className="hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors">
                                    Pricing
                                </Link>
                                <Link href="/contact" className="hover:text-primary px-3 py-2 rounded-md text-sm font-medium transition-colors">
                                    Contact
                                </Link>
                            </div>
                        </div>
                    </div>
                    <div className="hidden md:block">
                        <div className="ml-4 flex items-center md:ml-6 space-x-4">
                            <Link href="https://dev.dashboard.cloudtuner.ai/public" className="text-sm font-medium hover:text-white text-slate-300">
                                Log In
                            </Link>
                            <Link href="/tools/audit" className="bg-primary hover:bg-primary-dark text-dark-900 px-4 py-2 rounded-full text-sm font-bold transition-all">
                                Launch Audit Tool
                            </Link>
                        </div>
                    </div>
                    <div className="-mr-2 flex md:hidden">
                        <button
                            onClick={() => setIsOpen(!isOpen)}
                            className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-700 focus:outline-none"
                        >
                            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile menu */}
            {isOpen && (
                <div className="md:hidden bg-dark-800 border-b border-white/10">
                    <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
                        <Link href="/solutions/kubernetes-cost" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                            Cost Optimization
                        </Link>
                        <Link href="/solutions/smart-contract-audit" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                            Security Audit
                        </Link>
                        <Link href="/pricing" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                            Pricing
                        </Link>
                        <Link href="/contact" className="text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                            Contact
                        </Link>
                        <div className="pt-4 flex flex-col space-y-2">
                            <Link href="https://dev.dashboard.cloudtuner.ai/public" className="text-center text-gray-300 hover:text-white block px-3 py-2 rounded-md text-base font-medium">
                                Log In
                            </Link>
                            <Link href="/tools/audit" className="text-center bg-primary text-dark-900 block px-3 py-2 rounded-md text-base font-bold">
                                Launch Audit Tool
                            </Link>
                        </div>
                    </div>
                </div>
            )}
        </nav>
    );
}
