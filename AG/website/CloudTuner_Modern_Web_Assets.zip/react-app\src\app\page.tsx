import Hero from "../components/Hero";
import PricingTable from "../components/PricingTable";
import { Cloud, Shield, Zap, BarChart3 } from "lucide-react";

export default function Home() {
    return (
        <>
            <Hero />

            {/* Features Section */}
            <section className="py-24 bg-dark-800/50">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
                            One Platform. <span className="text-primary">Two Critical Missions.</span>
                        </h2>
                        <p className="text-slate-400 max-w-2xl mx-auto">
                            CloudTuner unifies infrastructure cost management and application security into a single, intelligent workflow.
                        </p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                        {[
                            {
                                icon: Cloud,
                                title: "Multi-Cloud Costing",
                                desc: "Unified view of AWS, Azure, GCP, and Kubernetes spend in one dashboard.",
                            },
                            {
                                icon: Shield,
                                title: "AI Security Audits",
                                desc: "Detect vulnerabilities in smart contracts instantly with our AI engine.",
                            },
                            {
                                icon: BarChart3,
                                title: "Granular Analytics",
                                desc: "Drill down to pod-level costs and line-by-line code analysis.",
                            },
                            {
                                icon: Zap,
                                title: "Automated Actions",
                                desc: "Auto-scale resources and auto-fix security issues with one click.",
                            },
                        ].map((feature, idx) => (
                            <div key={idx} className="p-6 rounded-xl bg-dark-900 border border-white/5 hover:border-primary/50 transition-all group">
                                <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4 group-hover:bg-primary/20 transition-colors">
                                    <feature.icon className="w-6 h-6 text-primary" />
                                </div>
                                <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                                <p className="text-slate-400 text-sm">{feature.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Pricing Preview */}
            <section className="py-24">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12 text-center">
                    <h2 className="text-3xl md:text-4xl font-heading font-bold text-white mb-4">
                        Simple, Transparent Pricing
                    </h2>
                    <p className="text-slate-400">Start for free, scale as you grow.</p>
                </div>
                <PricingTable />
            </section>
        </>
    );
}
