<?php get_header(); ?>

<div class="relative overflow-hidden">
    <!-- Background Glow -->
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/20 blur-[120px] rounded-full pointer-events-none"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32 relative z-10">
        <div class="text-center max-w-4xl mx-auto">
            <div class="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
                <span class="flex h-2 w-2 rounded-full bg-green-400 animate-pulse"></span>
                <span class="text-sm text-slate-300 font-medium">New: Kubernetes Cost Allocation API</span>
            </div>
            
            <h1 class="text-5xl md:text-7xl font-heading font-bold tracking-tight mb-8 text-white">
                Optimize Costs. <br />
                <span class="bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">Secure Contracts.</span>
            </h1>
            
            <p class="text-xl text-slate-400 mb-12 max-w-2xl mx-auto">
                The only platform that combines AI-driven cloud cost reduction with enterprise-grade smart contract security auditing.
            </p>
            
            <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href="/solutions/kubernetes-cost" class="w-full sm:w-auto px-8 py-4 rounded-full bg-primary hover:bg-primary-dark text-dark-900 font-bold text-lg transition-all flex items-center justify-center gap-2">
                    Reduce Cloud Spend
                </a>
                <a href="/tools/audit" class="w-full sm:w-auto px-8 py-4 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-white font-bold text-lg transition-all flex items-center justify-center gap-2 backdrop-blur-sm">
                    Audit Smart Contracts
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Main Content Loop -->
<section class="py-24 bg-dark-800/50">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('mb-12'); ?>>
                <h2 class="text-3xl font-bold text-white mb-4"><a href="<?php the_permalink(); ?>" class="hover:text-primary transition-colors"><?php the_title(); ?></a></h2>
                <div class="prose prose-invert max-w-none text-slate-400">
                    <?php the_excerpt(); ?>
                </div>
            </article>
        <?php endwhile; else : ?>
            <p class="text-white"><?php esc_html_e('Sorry, no posts matched your criteria.'); ?></p>
        <?php endif; ?>
    </div>
</section>

<?php get_footer(); ?>
