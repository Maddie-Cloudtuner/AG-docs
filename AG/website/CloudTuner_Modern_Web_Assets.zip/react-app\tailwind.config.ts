import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "#00D4FF", // Cyan/Teal
          dark: "#00A3C4",
        },
        secondary: {
          DEFAULT: "#6C5CE7", // Violet
          dark: "#5040B2",
        },
        dark: {
          900: "#0F172A", // Slate 900
          800: "#1E293B", // Slate 800
          700: "#334155", // Slate 700
        },
      },
      fontFamily: {
        sans: ["var(--font-inter)"],
        heading: ["var(--font-outfit)"],
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "hero-glow": "conic-gradient(from 180deg at 50% 50%, #00D4FF 0deg, #6C5CE7 180deg, #00D4FF 360deg)",
      },
    },
  },
  plugins: [],
};
export default config;
