import Link from "next/link";
import { ArrowRight, ShieldCheck, TrendingDown } from "lucide-react";

export default function Hero() {
    return (
        <div className="relative overflow-hidden">
            {/* Background Glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[500px] bg-primary/20 blur-[120px] rounded-full pointer-events-none" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-32 relative z-10">
                <div className="text-center max-w-4xl mx-auto">
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
                        <span className="flex h-2 w-2 rounded-full bg-green-400 animate-pulse"></span>
                        <span className="text-sm text-slate-300 font-medium">New: Kubernetes Cost Allocation API</span>
                    </div>

                    <h1 className="text-5xl md:text-7xl font-heading font-bold tracking-tight mb-8">
                        Optimize Costs. <br />
                        <span className="text-gradient">Secure Contracts.</span>
                    </h1>

                    <p className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto">
                        The only platform that combines AI-driven cloud cost reduction with enterprise-grade smart contract security auditing.
                    </p>

                    <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                        <Link href="/solutions/kubernetes-cost" className="w-full sm:w-auto px-8 py-4 rounded-full bg-primary hover:bg-primary-dark text-dark-900 font-bold text-lg transition-all flex items-center justify-center gap-2">
                            <TrendingDown className="w-5 h-5" />
                            Reduce Cloud Spend
                        </Link>
                        <Link href="/tools/audit" className="w-full sm:w-auto px-8 py-4 rounded-full bg-white/10 hover:bg-white/20 border border-white/10 text-white font-bold text-lg transition-all flex items-center justify-center gap-2 backdrop-blur-sm">
                            <ShieldCheck className="w-5 h-5" />
                            Audit Smart Contracts
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    );
}
