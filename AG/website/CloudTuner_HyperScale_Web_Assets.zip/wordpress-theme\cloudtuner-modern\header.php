<!DOCTYPE html>
<html <?php language_attributes(); ?> class="scroll-smooth">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class('bg-background text-slate-50 antialiased selection:bg-primary/30 selection:text-white'); ?>>

<!-- Floating Navbar -->
<nav class="fixed top-6 left-0 right-0 z-50 px-4">
    <div class="max-w-5xl mx-auto rounded-full bg-background/80 backdrop-blur-xl border border-white/10 shadow-2xl shadow-black/50 py-3 px-6 transition-all">
        <div class="flex items-center justify-between">
            <a href="<?php echo home_url(); ?>" class="flex items-center gap-2 group">
                <div class="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold font-heading text-lg">C</div>
                <span class="font-heading text-xl font-bold text-white tracking-tight">
                    Cloud<span class="text-primary">Tuner</span>
                </span>
            </a>
            
            <div class="hidden md:block">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'container' => false,
                    'menu_class' => 'flex items-center space-x-1',
                    'add_li_class' => 'px-4 py-2 text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 rounded-full transition-all'
                ));
                ?>
            </div>

            <div class="hidden md:flex items-center gap-4">
                <a href="https://dev.dashboard.cloudtuner.ai/public" class="text-sm font-medium text-slate-300 hover:text-white transition-colors">Sign In</a>
                <a href="/tools/audit" class="px-5 py-2 rounded-full bg-white text-black font-bold text-sm hover:bg-slate-200 transition-colors shadow-[0_0_20px_-5px_rgba(255,255,255,0.3)]">Start Audit</a>
            </div>
        </div>
    </div>
</nav>

<main class="min-h-screen">
