import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // "Deep Space" Palette
        background: "#030712", // Gray 950
        surface: {
          DEFAULT: "rgba(255, 255, 255, 0.03)",
          hover: "rgba(255, 255, 255, 0.08)",
          active: "rgba(255, 255, 255, 0.12)",
        },
        border: "rgba(255, 255, 255, 0.08)",

        // Accents
        primary: {
          DEFAULT: "#6366F1", // Indigo 500
          glow: "#818CF8",    // Indigo 400
        },
        secondary: {
          DEFAULT: "#A855F7", // Purple 500
        },
        success: {
          DEFAULT: "#10B981", // Emerald 500
          glow: "rgba(16, 185, 129, 0.3)",
        },

        // Text
        muted: "#94A3B8", // Slate 400
      },
      fontFamily: {
        sans: ["var(--font-jakarta)"],
        heading: ["var(--font-space)"],
        mono: ["var(--font-jetbrains)"],
      },
      backgroundImage: {
        "gradient-radial": "radial-gradient(var(--tw-gradient-stops))",
        "grid-pattern": "linear-gradient(to right, #1e293b 1px, transparent 1px), linear-gradient(to bottom, #1e293b 1px, transparent 1px)",
        "glow-conic": "conic-gradient(from 180deg at 50% 50%, #2a8af6 0deg, #a853ba 180deg, #e92a67 360deg)",
      },
      animation: {
        "pulse-slow": "pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "float": "float 6s ease-in-out infinite",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-20px)" },
        },
      },
    },
  },
  plugins: [],
};
export default config;
