<?php get_header(); ?>

<div class="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
    <!-- Background Effects -->
    <div class="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-primary/20 blur-[120px] rounded-full pointer-events-none opacity-50"></div>
    
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div class="text-center max-w-4xl mx-auto">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm">
                <span class="flex h-2 w-2 rounded-full bg-success animate-pulse"></span>
                <span class="text-xs font-mono text-success">SYSTEM OPERATIONAL</span>
            </div>
            
            <h1 class="text-5xl md:text-7xl font-heading font-bold tracking-tight mb-6 leading-[1.1] text-white">
                The Cloud Capital <br />
                <span class="bg-clip-text text-transparent bg-gradient-to-r from-primary to-secondary">Command Center</span>
            </h1>
            
            <p class="text-xl text-slate-400 mb-10 max-w-xl mx-auto leading-relaxed">
                Orchestrate your Kubernetes spend and secure your smart contracts from a single, high-precision dashboard.
            </p>
            
            <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                <a href="/solutions/kubernetes-cost" class="w-full sm:w-auto px-8 py-4 rounded-full bg-white text-black hover:bg-slate-200 font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-[0_0_30px_-5px_rgba(255,255,255,0.3)]">
                    Deploy Now
                </a>
                <a href="/tools/audit" class="w-full sm:w-auto px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium text-lg transition-all flex items-center justify-center gap-2 backdrop-blur-sm font-mono">
                    Read Docs
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Blog Loop -->
<section class="py-24 px-4 max-w-7xl mx-auto">
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class('glass-card rounded-3xl p-8'); ?>>
                <h2 class="text-2xl font-heading font-bold text-white mb-4"><a href="<?php the_permalink(); ?>" class="hover:text-primary transition-colors"><?php the_title(); ?></a></h2>
                <div class="text-slate-400 mb-4">
                    <?php the_excerpt(); ?>
                </div>
                <a href="<?php the_permalink(); ?>" class="text-primary font-bold hover:text-secondary transition-colors">Read More &rarr;</a>
            </article>
        <?php endwhile; endif; ?>
    </div>
</section>

<?php get_footer(); ?>
