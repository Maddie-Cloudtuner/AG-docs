<?php

function cloudtuner_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'cloudtuner'),
        'footer' => __('Footer Menu', 'cloudtuner'),
    ));
}
add_action('after_setup_theme', 'cloudtuner_setup');

function cloudtuner_scripts() {
    wp_enqueue_style('cloudtuner-style', get_stylesheet_uri());
    
    // Tailwind CDN (Dev)
    wp_enqueue_script('tailwindcss', 'https://cdn.tailwindcss.com', array(), '3.4.0', false);
    
    // Tailwind Config
    wp_add_inline_script('tailwindcss', "
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        background: '#030712',
                        primary: '#6366F1',
                        secondary: '#A855F7',
                        success: '#10B981',
                        surface: 'rgba(255, 255, 255, 0.03)',
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        heading: ['Space Grotesk', 'sans-serif'],
                        mono: ['JetBrains Mono', 'monospace'],
                    },
                    backgroundImage: {
                        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
                    }
                }
            }
        }
    ");
    
    // Google Fonts: Space Grotesk, Plus Jakarta Sans, JetBrains Mono
    wp_enqueue_style('google-fonts', 'https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500&family=Plus+Jakarta+Sans:wght@400;500;600&family=Space+Grotesk:wght@500;700&display=swap', array(), null);
}
add_action('wp_enqueue_scripts', 'cloudtuner_scripts');
