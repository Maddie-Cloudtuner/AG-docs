import Link from "next/link";
import { ArrowRight, Terminal } from "lucide-react";

export default function Hero() {
    return (
        <div className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
            {/* Background Effects */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-primary/20 blur-[120px] rounded-full pointer-events-none opacity-50" />
            <div className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-secondary/10 blur-[100px] rounded-full pointer-events-none opacity-30" />

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
                <div className="flex flex-col lg:flex-row items-center gap-16">

                    {/* Text Content */}
                    <div className="flex-1 text-center lg:text-left">
                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 mb-8 backdrop-blur-sm">
                            <span className="flex h-2 w-2 rounded-full bg-success animate-pulse"></span>
                            <span className="text-xs font-mono text-success">SYSTEM OPERATIONAL</span>
                            <span className="w-px h-3 bg-white/10 mx-1"></span>
                            <span className="text-xs text-slate-400">v2.4.0 Live</span>
                        </div>

                        <h1 className="text-5xl md:text-7xl font-heading font-bold tracking-tight mb-6 leading-[1.1]">
                            The Cloud Capital <br />
                            <span className="text-gradient">Command Center</span>
                        </h1>

                        <p className="text-xl text-muted mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                            Orchestrate your Kubernetes spend and secure your smart contracts from a single, high-precision dashboard.
                        </p>

                        <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4">
                            <Link href="https://dev.dashboard.cloudtuner.ai/public" className="w-full sm:w-auto px-8 py-4 rounded-full bg-white text-black hover:bg-slate-200 font-bold text-lg transition-all flex items-center justify-center gap-2 shadow-[0_0_30px_-5px_rgba(255,255,255,0.3)]">
                                Deploy Now
                                <ArrowRight className="w-5 h-5" />
                            </Link>
                            <Link href="/docs" className="w-full sm:w-auto px-8 py-4 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white font-medium text-lg transition-all flex items-center justify-center gap-2 backdrop-blur-sm font-mono">
                                <Terminal className="w-5 h-5 text-muted" />
                                Read Docs
                            </Link>
                        </div>

                        <div className="mt-12 flex items-center justify-center lg:justify-start gap-8 grayscale opacity-50">
                            {/* Placeholder logos for "Trusted By" */}
                            <div className="h-8 w-24 bg-white/20 rounded"></div>
                            <div className="h-8 w-24 bg-white/20 rounded"></div>
                            <div className="h-8 w-24 bg-white/20 rounded"></div>
                        </div>
                    </div>

                    {/* Dashboard Mockup */}
                    <div className="flex-1 w-full relative">
                        <div className="relative rounded-xl bg-dark-900 border border-white/10 shadow-2xl shadow-primary/20 overflow-hidden aspect-[4/3] group">
                            {/* Header */}
                            <div className="h-10 bg-dark-800 border-b border-white/5 flex items-center px-4 gap-2">
                                <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
                                <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
                                <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
                                <div className="ml-4 px-3 py-1 rounded bg-black/50 text-[10px] font-mono text-slate-500 flex-1 text-center">
                                    dashboard.cloudtuner.ai
                                </div>
                            </div>

                            {/* Content */}
                            <div className="p-6 grid grid-cols-2 gap-4">
                                <div className="col-span-2 h-32 rounded-lg bg-gradient-to-br from-primary/10 to-transparent border border-primary/20 p-4 relative">
                                    <div className="text-xs font-mono text-primary mb-2">TOTAL SPEND (YTD)</div>
                                    <div className="text-4xl font-heading font-bold text-white">$1,240,500</div>
                                    <div className="absolute bottom-4 right-4 text-success text-sm font-mono">-12.5% ▼</div>
                                </div>
                                <div className="h-32 rounded-lg bg-white/5 border border-white/5 p-4">
                                    <div className="text-xs font-mono text-muted mb-2">ACTIVE PODS</div>
                                    <div className="text-2xl font-heading font-bold text-white">842</div>
                                </div>
                                <div className="h-32 rounded-lg bg-white/5 border border-white/5 p-4">
                                    <div className="text-xs font-mono text-muted mb-2">SECURITY SCORE</div>
                                    <div className="text-2xl font-heading font-bold text-success">98/100</div>
                                </div>
                            </div>

                            {/* Hover Glow */}
                            <div className="absolute inset-0 bg-gradient-to-tr from-primary/10 via-transparent to-secondary/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                        </div>

                        {/* Floating Elements */}
                        <div className="absolute -right-8 -bottom-8 p-4 rounded-xl bg-dark-800 border border-white/10 shadow-xl animate-float">
                            <div className="flex items-center gap-3">
                                <div className="w-2 h-2 rounded-full bg-success animate-pulse"></div>
                                <div className="text-xs font-mono text-slate-300">Audit Complete: 0 Vulns</div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    );
}
