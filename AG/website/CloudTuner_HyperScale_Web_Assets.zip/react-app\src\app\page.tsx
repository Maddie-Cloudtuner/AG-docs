import Hero from "../components/Hero";
import BentoGrid from "../components/BentoGrid";
import PricingTable from "../components/PricingTable";

export default function Home() {
    return (
        <>
            <Hero />

            <div className="relative z-10">
                <BentoGrid />
            </div>

            {/* Pricing Section */}
            <section className="py-32 relative">
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-primary/5 to-transparent pointer-events-none"></div>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16 text-center">
                    <h2 className="text-3xl md:text-5xl font-heading font-bold text-white mb-6">
                        Transparent <span className="text-gradient">Pricing</span>
                    </h2>
                    <p className="text-muted text-lg">Enterprise-grade power, accessible to every team.</p>
                </div>
                <PricingTable />
            </section>
        </>
    );
}
