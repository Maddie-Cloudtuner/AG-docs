"use client";
import Link from "next/link";
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

export default function Navbar() {
    const [isOpen, setIsOpen] = useState(false);
    const [scrolled, setScrolled] = useState(false);

    useEffect(() => {
        const handleScroll = () => setScrolled(window.scrollY > 20);
        window.addEventListener("scroll", handleScroll);
        return () => window.removeEventListener("scroll", handleScroll);
    }, []);

    return (
        <nav className={`fixed top-6 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "px-4" : "px-4 md:px-0"}`}>
            <div className={`max-w-5xl mx-auto rounded-full border transition-all duration-300 ${scrolled
                    ? "bg-dark-900/80 backdrop-blur-xl border-white/10 shadow-2xl shadow-black/50 py-3 px-6"
                    : "bg-transparent border-transparent py-4 px-4"
                }`}>
                <div className="flex items-center justify-between">
                    {/* Logo */}
                    <Link href="/" className="flex items-center gap-2 group">
                        <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-primary to-secondary flex items-center justify-center text-white font-bold font-heading text-lg">
                            C
                        </div>
                        <span className="font-heading text-xl font-bold text-white tracking-tight">
                            Cloud<span className="text-primary">Tuner</span>
                        </span>
                    </Link>

                    {/* Desktop Nav */}
                    <div className="hidden md:flex items-center space-x-1">
                        {[
                            { name: "Platform", href: "/platform" },
                            { name: "Solutions", href: "/solutions" },
                            { name: "Pricing", href: "/pricing" },
                            { name: "Docs", href: "/docs" },
                        ].map((item) => (
                            <Link
                                key={item.name}
                                href={item.href}
                                className="px-4 py-2 text-sm font-medium text-slate-300 hover:text-white hover:bg-white/5 rounded-full transition-all"
                            >
                                {item.name}
                            </Link>
                        ))}
                    </div>

                    {/* Actions */}
                    <div className="hidden md:flex items-center gap-4">
                        <Link href="https://dev.dashboard.cloudtuner.ai/public" className="text-sm font-medium text-slate-300 hover:text-white transition-colors">
                            Sign In
                        </Link>
                        <Link
                            href="/tools/audit"
                            className="px-5 py-2 rounded-full bg-white text-black font-bold text-sm hover:bg-slate-200 transition-colors shadow-[0_0_20px_-5px_rgba(255,255,255,0.3)]"
                        >
                            Start Audit
                        </Link>
                    </div>

                    {/* Mobile Toggle */}
                    <div className="md:hidden">
                        <button onClick={() => setIsOpen(!isOpen)} className="text-slate-300 hover:text-white">
                            {isOpen ? <X /> : <Menu />}
                        </button>
                    </div>
                </div>
            </div>

            {/* Mobile Menu Overlay */}
            {isOpen && (
                <div className="absolute top-24 left-4 right-4 bg-dark-900/95 backdrop-blur-xl border border-white/10 rounded-2xl p-4 md:hidden flex flex-col space-y-2 shadow-2xl">
                    {["Platform", "Solutions", "Pricing", "Docs"].map((item) => (
                        <Link
                            key={item}
                            href={`/${item.toLowerCase()}`}
                            className="px-4 py-3 text-slate-300 hover:bg-white/5 rounded-xl"
                        >
                            {item}
                        </Link>
                    ))}
                    <div className="h-px bg-white/10 my-2"></div>
                    <Link href="/login" className="px-4 py-3 text-slate-300">Sign In</Link>
                    <Link href="/audit" className="px-4 py-3 bg-primary text-white rounded-xl text-center font-bold">Start Audit</Link>
                </div>
            )}
        </nav>
    );
}
